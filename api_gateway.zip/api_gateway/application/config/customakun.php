<?php defined('BASEPATH') or exit('No direct script access allowed');
/*------------------- Gateway Name ----------------------*/
$config['AppsName'] = 'Katalog Web Service RS Tk.III dr. Reksodiwiryo';
/*------------------- AKun Integrasi BSSN ----------------------*/
$config['UrlBSSN'] = 'http://10.0.8.80';
$config['TokenBSSN'] = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoxLCJlbWFpbCI6ImFkbWluQHR0ZS5jb20iLCJuaWsiOiIxMTIyMzMxMTIyMzM1NTIyIiwiZXhwIjoxNzA1NDk3NTU0fQ.rvhu_9pZEzIodlv20iHSra0KYDt0szNRAsQr_kuTnsQ';
$config['UsernameBSSN'] = 'esign';
$config['PasswordBSSN'] = 'qwerty';
